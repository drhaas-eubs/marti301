# Patch for `authors.py` — wire the generated sketches into the Slibrary

After running `python3 generate.py`, you'll have 9 sketches in `img/`.
To make the existing slibrary build use them, add a single key to each
matching entry in `authors.py`.

The `generator.py` already supports `image_href` (per the README: "Drop a
square (or near-square) sketch image into a sibling folder, e.g. `img/`,
then for the relevant author set `image_href`"), so this is a one-line
change per author.

## The 9 edits

```python
# Find each author entry by id and add image_href:

{
    "id": "michael_porter",
    # …existing keys…
    "image_href": "img/michael_porter.jpg",
},
{
    "id": "clayton_christensen",
    # …existing keys…
    "image_href": "img/clayton_christensen.jpg",
},
{
    "id": "garry_kasparov",
    # …existing keys…
    "image_href": "img/garry_kasparov.jpg",
},
{
    "id": "john_boyd",
    # …existing keys…
    "image_href": "img/john_boyd.jpg",
},
{
    "id": "dave_snowden",
    # …existing keys…
    "image_href": "img/dave_snowden.jpg",
},
{
    "id": "russell_ackoff",
    # …existing keys…
    "image_href": "img/russell_ackoff.jpg",
},
{
    "id": "philip_kotler",
    # …existing keys…
    "image_href": "img/philip_kotler.jpg",
},
{
    "id": "cathy_oneil",
    # …existing keys…
    "image_href": "img/cathy_oneil.jpg",
},
{
    "id": "nassim_taleb",
    # …existing keys…
    "image_href": "img/nassim_taleb.jpg",
},
```

## Then rebuild the SVGs

```bash
cd ~/EUBS-Courses/marti301/slibrary    # or wherever the slibrary lives
python3 build.py
```

All 46 SVGs (23 thumbnail + 23 long-desc) regenerate. The 9 with
`image_href` set will now embed the sketch into the head silhouette;
the other 14 keep the existing stylised silhouette placeholder.

## Verify

Open `svg/michael_porter_thumbnail.svg` in a browser. You should see
the sketch embedded inside the round head outline. Same for
`svg/michael_porter_longdesc.svg` (larger format).

If the sketch sits poorly in the silhouette (too high, too low, too
zoomed), regenerate with a different `crop_bias_y` in
`manifest.py` and re-run `generate.py` — the pipeline overwrites the
existing JPEG cleanly.

## Footer credit on slibrary.html

Add to the bottom of `slibrary.html`:

```html
<footer class="credits">
  Portrait sketches derived from
  <a href="CREDITS.md">Wikimedia Commons sources</a>;
  pencil-sketch processing applied for visual consistency.
  See CREDITS.md for full attribution.
</footer>
```

## Commit message

```
Add pencil-sketch portraits for 9 framework authors

— derived from Wikimedia Commons (CC BY / CC BY-SA / PD)
— full attribution in CREDITS.md
— remaining 14 authors keep silhouette placeholder pending sourcing
```

---

©️ Dr. Hildegard Haas · MARTI301
