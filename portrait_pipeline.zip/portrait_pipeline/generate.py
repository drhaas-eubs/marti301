#!/usr/bin/env python3
"""
generate.py — Download Wikimedia Commons portraits, convert to B/W pencil
sketches, save into ./img/ for the MARTI301 Slibrary.

Usage (from inside the portrait_pipeline folder):

    python3 -m venv .venv
    source .venv/bin/activate
    pip install pillow requests
    python3 generate.py

Outputs:
    img/{author_id}.jpg                 — final 600×600 B/W pencil sketch
    img/_originals/{author_id}.jpg      — kept for re-cropping later if needed
    CREDITS.md                          — provenance for each portrait

Network: needs commons.wikimedia.org and upload.wikimedia.org reachable.
Standard household / university wifi is fine. No VPN needed.

If a `commons_file` is None in manifest.py, the script will print the
category URL and skip that author — open the URL, pick the file, paste
its name in manifest.py, re-run.
"""

from __future__ import annotations

import io
import json
import os
import sys
from pathlib import Path
from urllib.parse import unquote

import requests
from PIL import Image, ImageChops, ImageFilter, ImageOps

from manifest import PORTRAITS

# ───────────────────────────────────────────────────────────────────────
# Paths
# ───────────────────────────────────────────────────────────────────────
ROOT     = Path(__file__).resolve().parent
IMG_DIR  = ROOT / "img"
ORIG_DIR = IMG_DIR / "_originals"
IMG_DIR.mkdir(exist_ok=True)
ORIG_DIR.mkdir(exist_ok=True)

CREDITS_PATH = ROOT / "CREDITS.md"

# Wikimedia API endpoint
MW_API = "https://commons.wikimedia.org/w/api.php"
UA     = "MARTI301-Slibrary/1.0 (educational; contact: drhaas-eubs@github)"

# Final sketch size (matches the SVG long-desc portrait slot)
OUT_SIZE = 600


# ───────────────────────────────────────────────────────────────────────
# Wikimedia helpers
# ───────────────────────────────────────────────────────────────────────
def resolve_commons_url(file_title: str) -> tuple[str, dict]:
    """
    Given a 'File:Foo.jpg' title, ask the MediaWiki API for the actual
    upload URL plus license / author metadata.

    Returns (image_url, metadata_dict).
    """
    params = {
        "action":   "query",
        "format":   "json",
        "titles":   file_title,
        "prop":     "imageinfo",
        "iiprop":   "url|extmetadata|user",
    }
    r = requests.get(MW_API, params=params, headers={"User-Agent": UA}, timeout=30)
    r.raise_for_status()
    data = r.json()
    pages = data.get("query", {}).get("pages", {})
    if not pages:
        raise RuntimeError(f"No page found for {file_title}")
    page = next(iter(pages.values()))
    if "imageinfo" not in page:
        raise RuntimeError(f"No imageinfo for {file_title} — does the file exist?")
    info = page["imageinfo"][0]
    meta = info.get("extmetadata", {})
    pretty_meta = {
        "license":   meta.get("LicenseShortName", {}).get("value", "unknown"),
        "author":    _strip_html(meta.get("Artist", {}).get("value", "unknown")),
        "credit":    _strip_html(meta.get("Credit", {}).get("value", "")),
        "url":       info["url"],
        "descr_url": info.get("descriptionurl", ""),
    }
    return info["url"], pretty_meta


def _strip_html(s: str) -> str:
    """Crude HTML-stripper for the author/credit fields."""
    import re
    return re.sub(r"<[^>]+>", "", s).strip()


def download_image(url: str, dest: Path) -> Image.Image:
    """Stream the image to disk and load with Pillow."""
    r = requests.get(url, headers={"User-Agent": UA}, timeout=60, stream=True)
    r.raise_for_status()
    raw = r.content
    dest.write_bytes(raw)
    return Image.open(io.BytesIO(raw)).convert("RGB")


# ───────────────────────────────────────────────────────────────────────
# Image processing
# ───────────────────────────────────────────────────────────────────────
def square_crop(img: Image.Image, bias_y: float = 0.4) -> Image.Image:
    """
    Centre-square crop. `bias_y` shifts the crop window vertically:
    0.0 keeps the top, 1.0 keeps the bottom, 0.4 is a typical
    portrait crop that puts the face slightly above centre.
    """
    w, h = img.size
    side = min(w, h)
    if w >= h:
        # landscape: keep full height, crop sides centred
        left   = (w - side) // 2
        upper  = 0
    else:
        # portrait: keep full width, crop top/bottom with bias
        left   = 0
        upper  = int((h - side) * bias_y)
    return img.crop((left, upper, left + side, upper + side))


def pencil_sketch(img: Image.Image) -> Image.Image:
    """
    Classical 'colour dodge' pencil-sketch effect, then a touch of
    posterisation to deepen the line work.

    Works well on cleanly-lit head-and-shoulders portraits. If the
    source has heavy backlight or low contrast you may want to apply
    Pillow's ImageOps.autocontrast() first.
    """
    grey      = img.convert("L")
    inverted  = ImageOps.invert(grey)
    blurred   = inverted.filter(ImageFilter.GaussianBlur(radius=18))
    blurback  = ImageOps.invert(blurred)
    # colour-dodge blend: result = base * 256 / (256 - blend)
    sketch = ImageChops.subtract_modulo(
        ImageChops.constant(grey, 255),
        ImageChops.subtract_modulo(
            ImageChops.constant(grey, 255),
            ImageChops.multiply(grey, blurback),
        ),
    )
    # The simpler "divide" route gives the cleanest result on photos
    # with neutral lighting. Use that as the default:
    sketch = _color_dodge(grey, blurback)
    # Deepen mid-tones a hair
    sketch = ImageOps.autocontrast(sketch, cutoff=1)
    return sketch


def _color_dodge(base: Image.Image, blend: Image.Image) -> Image.Image:
    """result = base * 256 / (256 - blend), clipped to 0-255."""
    import numpy as np
    b = np.asarray(base,  dtype=np.int32)
    d = np.asarray(blend, dtype=np.int32)
    out = b * 256 // (257 - d)
    out = np.clip(out, 0, 255).astype("uint8")
    return Image.fromarray(out, mode="L")


def process_one(entry: dict) -> dict | None:
    """Resolve, download, crop, sketch, save. Returns CREDITS row or None."""
    aid       = entry["author_id"]
    file_name = entry["commons_file"]
    cat       = entry["commons_category"]
    bias      = entry.get("crop_bias_y", 0.40)

    if not file_name:
        print(f"  ⏭  {aid}: no commons_file set — open "
              f"https://commons.wikimedia.org/wiki/{cat} "
              f"and paste the filename into manifest.py")
        return None

    print(f"  →  {aid}: resolving {file_name}…")
    try:
        url, meta = resolve_commons_url(file_name)
    except Exception as e:
        print(f"     ✗ resolve failed: {e}")
        return None

    print(f"     downloading {url}")
    orig_path = ORIG_DIR / f"{aid}{Path(unquote(url)).suffix.lower()}"
    try:
        img = download_image(url, orig_path)
    except Exception as e:
        print(f"     ✗ download failed: {e}")
        return None

    cropped  = square_crop(img, bias_y=bias).resize(
                   (OUT_SIZE, OUT_SIZE), Image.LANCZOS)
    sketched = pencil_sketch(cropped)

    out_path = IMG_DIR / f"{aid}.jpg"
    sketched.save(out_path, "JPEG", quality=88)
    print(f"     ✓ wrote {out_path.relative_to(ROOT)}")

    return {
        "author_id":     aid,
        "source_file":   file_name,
        "source_url":    meta["descr_url"],
        "image_url":     url,
        "license":       meta["license"],
        "author":        meta["author"],
        "credit":        meta["credit"],
    }


# ───────────────────────────────────────────────────────────────────────
# Main
# ───────────────────────────────────────────────────────────────────────
def main() -> int:
    print(f"Processing {len(PORTRAITS)} portraits → {IMG_DIR}/\n")
    rows: list[dict] = []
    skipped = 0
    for entry in PORTRAITS:
        row = process_one(entry)
        if row is None:
            skipped += 1
        else:
            rows.append(row)
        print()

    # Write CREDITS.md
    lines = [
        "# Portrait credits — MARTI301 Slibrary",
        "",
        "All sources are Wikimedia Commons. Each entry below cites the",
        "original file page (where licence + photographer are recorded)",
        "and the direct image URL used by the pipeline.",
        "",
        "| Author | Source file | Licence | Photographer / credit |",
        "|---|---|---|---|",
    ]
    for r in rows:
        lines.append(
            f"| `{r['author_id']}` "
            f"| [{r['source_file']}]({r['source_url']}) "
            f"| {r['license']} "
            f"| {r['author']} {('— ' + r['credit']) if r['credit'] else ''} |"
        )
    CREDITS_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {CREDITS_PATH.relative_to(ROOT)}")

    print(f"\nDone. {len(rows)} portraits generated, {skipped} skipped.")
    if skipped:
        print("→ Fill in the missing `commons_file` entries in manifest.py "
              "and re-run.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
