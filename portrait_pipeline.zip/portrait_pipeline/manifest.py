"""
manifest.py — Source-of-truth list of the 9 Commons-confirmed Slibrary portraits.

For each author:
  - author_id: must match the key in authors.py
  - commons_file: a specific File:NAME.ext on Wikimedia Commons (preferred)
  - commons_category: fallback Category page if no specific file is yet confirmed
  - crop_bias_y: vertical bias for the square crop (0.0 = top, 0.5 = center,
                 1.0 = bottom). Faces usually sit above center -> 0.30-0.42.
  - notes: provenance / picking rationale

Files marked "VERIFY" need you to open the Commons category in a browser and
pick a clean head-and-shoulders shot, then plug the exact filename in.
The pipeline will work the moment you fill those in.
"""

PORTRAITS = [
    # ───── UNIT 1 ──────────────────────────────────────────────────────
    {
        "author_id":        "michael_porter",
        "commons_file":     None,                                # VERIFY
        "commons_category": "Category:Michael_Porter",
        "crop_bias_y":      0.38,
        "notes":            "Category has 5 files; pick the cleanest "
                            "frontal Harvard / WEF portrait.",
    },
    {
        "author_id":        "clayton_christensen",
        "commons_file":     "File:Clayton_Christensen_World_Economic_Forum_2013.jpg",  # VERIFY exact name
        "commons_category": "Category:Clayton_Christensen",
        "crop_bias_y":      0.38,
        "notes":            "Remy Steinegger / WEF 2013. The canonical "
                            "Christensen portrait — used by Fast Company, "
                            "Religion News, etc. If the filename above 404s, "
                            "browse the category to find the WEF 2013 file.",
    },
    {
        "author_id":        "garry_kasparov",
        "commons_file":     "File:Garry_Kasparov_IMG_0130.JPG",
        "commons_category": "Category:Garry_Kasparov_in_2012",
        "crop_bias_y":      0.40,
        "notes":            "David Monniaux, 2012 Turing 100 Manchester. "
                            "CC BY-SA 3.0. Excellent frontal portrait.",
    },

    # ───── UNIT 2 ──────────────────────────────────────────────────────
    {
        "author_id":        "john_boyd",
        "commons_file":     None,                                # VERIFY
        "commons_category": "Category:John_Boyd_(military_strategist)",
        "crop_bias_y":      0.42,
        "notes":            "USAF photo, public domain. The young-major "
                            "wingman portrait used by Army War College's "
                            "Great Strategists series. Browse the category.",
    },
    {
        "author_id":        "dave_snowden",
        "commons_file":     None,                                # VERIFY
        "commons_category": "Category:Dave_Snowden",
        "crop_bias_y":      0.40,
        "notes":            "11 files. Pick a recent conference photo with "
                            "frontal eye contact.",
    },
    {
        "author_id":        "russell_ackoff",
        "commons_file":     None,                                # VERIFY
        "commons_category": "Category:Russell_L._Ackoff",
        "crop_bias_y":      0.42,
        "notes":            "Pick the later-life lecture portrait if "
                            "available — Ackoff is most recognised in his "
                            "70s/80s with white hair.",
    },

    # ───── UNIT 3 ──────────────────────────────────────────────────────
    {
        "author_id":        "philip_kotler",
        "commons_file":     "File:Kotler-DSC_0510.jpg",
        "commons_category": "Category:Philip_Kotler",
        "crop_bias_y":      0.38,
        "notes":            "Clean frontal portrait. Alternatives in the "
                            "category: Philip_Kotler_at_brandsmart_2007_in_Chicago.jpg, "
                            "Prof._Kotler_při_přednášce_v_Praze.jpg.",
    },

    # ───── UNIT 4 ──────────────────────────────────────────────────────
    {
        "author_id":        "cathy_oneil",
        "commons_file":     None,                                # VERIFY
        "commons_category": "Category:Cathy_O%E2%80%99Neil",
        "crop_bias_y":      0.38,
        "notes":            "Note the curly apostrophe in the URL. "
                            "Pick a TED / journalism-conference photo.",
    },
    {
        "author_id":        "nassim_taleb",
        "commons_file":     "File:Taleb_mug.JPG",
        "commons_category": "Category:Nassim_Nicholas_Taleb",
        "crop_bias_y":      0.42,
        "notes":            "Owner-released by Taleb himself. Photographer "
                            "credit: Sarah Josephine Taleb. Already a "
                            "head-and-shoulders crop.",
    },
]
