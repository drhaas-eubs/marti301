# MARTI301 · Slibrary · Portrait Pipeline

A small Python tool that takes the **9 framework authors with confirmed
Wikimedia Commons portraits**, downloads each, and converts it to a 600×600
B/W pencil-sketch JPEG suitable for the `marti301/img/` folder of the
Slibrary repo.

---

## What's in this bundle

| File | Role |
|---|---|
| `manifest.py` | The 9-author source-of-truth: each entry lists the Commons file (where confirmed) and the category page (fallback). |
| `generate.py` | Resolves filenames → URLs via the MediaWiki API, downloads, crops, sketches, writes `img/{author_id}.jpg`. |
| `requirements.txt` | `pillow`, `requests`, `numpy`. |
| `README.md` | This file. |
| `authors_patch.md` | Drop-in snippet for `authors.py` once the sketches are made. |

---

## Run it

From the Mac Mini (anywhere you have network — your home wifi is fine):

```bash
cd ~/Downloads
unzip portrait_pipeline.zip
cd portrait_pipeline

# One-time setup
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Generate the sketches
python3 generate.py
```

Output:

```
img/
  michael_porter.jpg            ← only if you fill in commons_file (see below)
  clayton_christensen.jpg       ← runs out-of-the-box (filename pre-filled)
  garry_kasparov.jpg            ← runs out-of-the-box
  john_boyd.jpg                 ← needs commons_file
  dave_snowden.jpg              ← needs commons_file
  russell_ackoff.jpg            ← needs commons_file
  philip_kotler.jpg             ← runs out-of-the-box
  cathy_oneil.jpg               ← needs commons_file
  nassim_taleb.jpg              ← runs out-of-the-box
  _originals/                   ← downloaded source files, kept for re-cropping
CREDITS.md                      ← auto-generated provenance log
```

4 of the 9 portraits will generate immediately. For the other 5, the script
will print the Commons category URL and skip them — open the URL, pick the
cleanest head-and-shoulders shot, paste the exact `File:Foo.jpg` name into
`manifest.py`, re-run.

---

## How the sketch effect works

`generate.pencil_sketch()` uses the classical **colour-dodge** technique:

1. Convert to greyscale.
2. Invert.
3. Apply Gaussian blur (radius 18).
4. Invert again.
5. `result = base * 256 / (257 - blurred_inverted)` — the colour-dodge blend.
6. Stretch contrast slightly with `ImageOps.autocontrast`.

The result is a soft, photo-derived pencil sketch that holds up well at
small sizes (the SVG long-desc slot is 200 × 200) and renders cleanly
on the gallery thumbnails.

If a particular portrait comes out too dark (heavy shadow on one side),
either:
- bump the blur radius up (try 25 in `pencil_sketch`), or
- pre-process with `ImageOps.autocontrast(img, cutoff=2)` before passing
  it to `pencil_sketch`.

---

## Adjusting crops

If the default `crop_bias_y=0.40` cuts off someone's chin or hairline,
just edit the `crop_bias_y` value in `manifest.py` for that author and
re-run. Lower values (0.30) keep more of the top, higher (0.50) keep
more of the bottom.

`_originals/` keeps the full downloaded source so you don't need to
re-fetch from Commons when iterating on the crop.

---

## Filling in the missing 5

For each entry where `commons_file` is `None`:

1. Open the URL from `commons_category` in your browser, e.g.
   `https://commons.wikimedia.org/wiki/Category:Cathy_O%E2%80%99Neil`
2. Click each thumbnail. Look for:
   - Clean head-and-shoulders or upper-torso composition
   - Frontal or 3/4 view (avoid extreme profiles)
   - Decent lighting — colour-dodge sketches struggle with hard backlight
   - Resolution ≥ 600 × 600 ideally
3. On the file page, the title at the top is the exact filename. It looks
   like `File:Cathy_ONeil_TED2017.jpg` (with the `File:` prefix).
4. Paste that whole title (including `File:`) into the `commons_file`
   value for that author in `manifest.py`.
5. Re-run `python3 generate.py`. Already-generated portraits won't be
   re-downloaded.

---

## After the sketches are made

See `authors_patch.md` for the one-line edit per author that wires the
sketches into the existing slibrary build:

```python
# In authors.py, on each of the 9 entries:
"image_href": "img/michael_porter.jpg",
```

Then from the slibrary directory:

```bash
python3 build.py
```

All 46 SVGs regenerate with the sketches embedded in the head silhouette.

---

## Caveats

- **Licence compliance**: every Commons file we use is at minimum CC BY-SA
  3.0 (most are CC BY 4.0 or public domain). The auto-generated
  `CREDITS.md` records the photographer and licence per portrait — keep
  that file in the slibrary repo and add a footer to `slibrary.html`
  pointing readers to it.
- **The 14 authors with no Commons portrait** (Perez, Agrawal/Gans/Goldfarb,
  Wilson & Daugherty, Shostack, Reichheld, Schwartz et al. partial,
  Markowitz, Litterman, French, Muldowney, López de Prado) are not handled
  by this pipeline. For those, source from faculty / corporate leadership
  pages and process them manually with the same `pencil_sketch()`
  function — the script will accept any local image you drop into
  `_originals/{author_id}.jpg`.

---

©️ Dr. Hildegard Haas · MARTI301 · AI in Investment & Competitiveness · EU Business School
